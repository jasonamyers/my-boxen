# Vagrant Puppet Module for Boxen

Install [Vagrant](http://www.vagrantup.com/) on your Mac.

## Usage

```puppet
include vagrant
```

## Required Puppet Modules

* `boxen`
