# nginx Puppet Module for Boxen

## Usage

```puppet
include nginx
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
